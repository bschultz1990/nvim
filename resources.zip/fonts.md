﻿# Nerd Fonts

- JetBrains Mono: `https://github.com/ryanoasis/nerd-fonts/releases/download/v3.2.1/JetBrainsMono.zip`
- MesloLG: `https://github.com/ryanoasis/nerd-fonts/releases/download/v3.2.1/Meslo.zip`
